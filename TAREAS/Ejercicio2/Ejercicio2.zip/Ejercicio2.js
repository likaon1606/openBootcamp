const datos = [
    nombre= "Ariel", 
    edad = 42,
    eresDesarrollador = true,
    fechaDeNacimiento = new Date("april 16 1980")
]

const libroFavorito = {
    titulo: "Valle Negro",
    autor: "Hugo Wast",
    fecha: new Date("february 16 1942"),
    url: "https://www.casadellibro.com/libro-valle-negro/mkt0003574827/4965576"
}

console.log(datos);
console.log(libroFavorito);
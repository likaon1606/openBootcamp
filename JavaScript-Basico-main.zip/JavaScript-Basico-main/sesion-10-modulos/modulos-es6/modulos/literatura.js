const getAutor = () => {
    return "Miguel de Cervantes"
}

export const libro = "Don Quijote de la Mancha"

export default getAutor
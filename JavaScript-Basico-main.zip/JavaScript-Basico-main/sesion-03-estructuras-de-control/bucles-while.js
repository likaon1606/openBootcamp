// Bucles While

let i = 0;
let max = 10;
while (i < max) {
    console.log(i);
    i++;
}

i = 15;
// Do...while
do {
    console.log("Estoy en el do while")
} while (i < max)
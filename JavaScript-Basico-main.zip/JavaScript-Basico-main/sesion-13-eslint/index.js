var nombre = "Gorka"

var nombre2 = "Maria"

var objeto = {
    nombre: "Círculo",
    radio: 2
}
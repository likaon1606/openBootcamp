// Este es el archivo que vamos a utilizar

const nombre = "Gorka"


/* eslint-disable */

const persona2 = 'Maria';

/* eslint-enable */

// En esta línea quiero tener comillas simples (quiero que me desactives la regla de las comillas dobles)
const nuevoString = 'Esto es un nuevo string'; // eslint-disable-line

/* eslint-disable-next-line indent */
  const string2 = "Más strings"

console.log("Hola")

const persona3 = "Maria"


const nombre3 = "Julián"

console.log(4)

// Este es el mensaje de bienvenida
console.log("Esta es la puerta de entrada al proyecto")

/*
    Esta es la parte intermedia de nuestro proyecto
    En esta parte realizamos los chequeos necesarios
    Por último vamos a la última línea de saludo
    Esto también está comentado
    Aquí también
 */

// Este va a ser el mensaje que se envía para despedir
console.log("Adiós")
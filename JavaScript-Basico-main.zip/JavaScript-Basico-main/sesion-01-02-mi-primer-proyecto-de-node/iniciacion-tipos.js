// Tipos primitivos

// number
4;
0;

// string
"Hola mundo";
'Hola mundo';
`Hola mundo`;

// booleanos
true;
false;

// nulo y undefined
null;
undefined;

// null, undefined, false, 0 ==> Todas son Falsy
console.log(null === undefined)

if (true) {
    console.log("cumple")
} else {
    console.log("no cumple")
}



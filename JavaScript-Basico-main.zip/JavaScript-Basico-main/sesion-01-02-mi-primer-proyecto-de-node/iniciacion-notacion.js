// Notación
// ; -> Delimitar el final de una línea
const b = 4;
b + 4;

// . -> Se utiliza en los objetos para acceder a los atributos 
// movil.anchura

// [] -> listas, arreglos o arrays
const ar = [1, 2, 3, 4]
console.log(ar[2])

// () -> Funciones
function suma(a, b) {
    // Se escribe la función
}

// {} -> Llaves para objetos, funciones y estructuras de control
const movil = {
    anchura: 5,
    altura: 10
}

if (true) {
    // todo lo que haya entre llaves

    const constante2 = "hola"

}

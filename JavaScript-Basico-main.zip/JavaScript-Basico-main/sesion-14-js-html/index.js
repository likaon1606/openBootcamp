const a = 4
const b = 8

console.log(a * b)
console.log("Hola")

const p = document.getElementById("parrafo")

console.log(p)
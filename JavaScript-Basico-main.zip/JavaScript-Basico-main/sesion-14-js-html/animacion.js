new TypeIt("#myElement", {
    strings: "Este es un texto personalizado",
}).go();